/**********************************************************************************************************************************
Programmer: Esteban Bravo.
Program name: FruitMarketPlace (Main program)
Purpose: This program starts all threads and begins the Fruit Market PLace Simulation. It consists of Farmers that place fruits
for sale on the market and customers who wish to buy those fruits from the market. The market has limited capacity of 4 maximum
fruits stored in the market so the farmers have to stand in a queue if the capacity is exceeded. Finally, if a freuit is not
available for purchase than the customer has to wait for the fuits to be available on the market.
**********************************************************************************************************************************/

public class FruitMarketPlace
{
	public static void main(String[] args)
	{
		//Starts the theads.
		FruitQueue queue = new FruitQueue(3);
		new FuitProducer(queue).start();
		new FuitProducer(queue).start();
		new FuitProducer(queue).start();
		new FuitProducer(queue).start();
		new FruitCustomer(queue).start();
		new FruitCustomer(queue).start();
		new FruitCustomer(queue).start();
		new FruitCustomer(queue).start();
	}
}