/**********************************************************************************************************************************
Programmer: Esteban Bravo.
Program name: FruitMarketPlace (FuitProducer)
Purpose: This program serves as the producer. It generates four strings for the four fruits (apple, orange, grape, and watermelon)
and sends them to the FruitQueue class for them to be used.
**********************************************************************************************************************************/

public class FuitProducer extends Thread
{
	private FruitQueue queue = null;

	public FuitProducer(FruitQueue queue)
	{
		this.queue = queue;
		this.queue = queue;
		this.queue = queue;
		this.queue = queue;

	}
	// run() method that sends the type of fruits to the FruitQueue class
	public void run()
	{
		for(int i = 0; i < 5; i++)
		{
			queue.put(generateMessage());
			queue.put3(generateMessage3());
			queue.put2(generateMessage2());
			queue.put4(generateMessage4());
		}
	}

	// Generates apples
	private synchronized String generateMessage()
	{
		String msg = "Apple";
		return msg;
	}
	// Generates oranges.
	private synchronized String generateMessage2()
	{
		String msg2 = "Orange";
		return msg2;
	}
	// Generates Grape.
	private synchronized String generateMessage3()
	{
		String msg3 = "Grape";
		return msg3;
	}
	// Generates Watermelon.
	private synchronized String generateMessage4()
	{
		String msg4 = "Watermelon";
		return msg4;
	}
}