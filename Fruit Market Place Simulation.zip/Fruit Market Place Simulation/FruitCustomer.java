/**********************************************************************************************************************************
Programmer: Esteban Bravo.
Program name: FruitMarketPlace (FuitCustomer)
Purpose: This program serves as the Consumer. It calls functions from the FruitQueue class that allow each consumer to buy fruits
and if the market has no fruits then it will wait for any farmer to place a fruit for sale.
**********************************************************************************************************************************/


public class FruitCustomer extends Thread
{
	private FruitQueue queue = null;

	public FruitCustomer(FruitQueue queue)
	{
		this.queue = queue;
		this.queue = queue;
		this.queue = queue;
		this.queue = queue;
	}
	// run() method for allowing the customer to buy a fruit from the market.
	public void run()
	{
		for(int i = 0; i < 5; i++)
		{
			System.out.println("Customer 1 bought one " + queue.get());
		}
		for(int i = 0; i < 5; i++)
		{
			System.out.println("Customer 3 bought one " + queue.get2());
		}
		for(int i = 0; i < 5; i++)
		{
			System.out.println("Customer 2 bought one " + queue.get3());
		}
		for(int i = 0; i < 5; i++)
		{
			System.out.println("Customer 4 bought one " + queue.get4());
		}

	}

}