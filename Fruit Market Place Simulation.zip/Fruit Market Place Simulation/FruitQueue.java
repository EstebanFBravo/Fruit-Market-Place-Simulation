/**********************************************************************************************************************************
Programmer: Esteban Bravo.
Program name: FruitMarketPlace (FruitQueue)
Purpose: This program creates the Queue for the market, and creates methods for synchronization between the customers and the
farmers. It contains put() and get() methods for the farmers and customers and prevent them from buying from the market
if its empty or prevent them from selling more fruits if the market is at its maximum capasity.
**********************************************************************************************************************************/

import java.util.ArrayList;
import java.util.List;

public class FruitQueue
{
		private int bufferSize;  // buffer size

		// buffer list of message.
		private List<String> buffer = new ArrayList<String>();

		//constructs the message queue with the given buffer size.
		public FruitQueue(int bufferSize)
		{
			if(bufferSize <= 0)
				throw new IllegalArgumentException("Market size is illegal ");

			this.bufferSize = bufferSize;
		}

		// synchronized keyword mothod to check if the buffer is full.
		public synchronized boolean isFull()
		{
			return buffer.size() == bufferSize;
		}

		// synchronized keyword mothod to check if the buffer is empty
		public synchronized boolean isEmpty()
		{
			return buffer.isEmpty();
		}


		// synchronized method that reads the sent fruit from the FuitProducer class.
		public synchronized void put(String message)
		{
			// Makes the farmer wait in a Queue if the market is full.
			while(isFull())
			{
				System.out.println("Farmer 1 waiting to put one Apple up for sale...");
				try
				{
					// sets the current thread to wait
					wait();
				}
				catch(InterruptedException ex)
				{
					System.out.println(ex);
				}
			}
			buffer.add(message);
			System.out.println("Farmer 1 put " + message + " up for sale");

			// Lets all the other threads that they can continue.
			notifyAll();
		}


		// synchronized method that reads the sent fruit from the FuitProducer class.
		public synchronized void put2(String message2)
		{
			// Makes the farmer wait in a Queue if the market is full.
			while(isFull())
			{
				System.out.println("Farmer 2 waiting to put one Orange up for sale...");
				try
				{
					// sets the current thread to wait
					wait();
				}
				catch(InterruptedException ex)
				{
					System.out.println(ex);
				}
			}
			buffer.add(message2);
			System.out.println("Farmer 2 put " + message2 + " up for sale");

			// Lets all the other threads that they can continue.
			notifyAll();
		}


		// synchronized method that reads the sent fruit from the FuitProducer class.
		public synchronized void put3(String message3)
		{
			// Makes the farmer wait in a Queue if the market is full.
			while(isFull())
			{
				System.out.println("Farmer 3 waiting to put one Grape up for sale...");
				try
				{
					// sets the current thread to wait
					wait();
				}
				catch(InterruptedException ex)
				{
					System.out.println(ex);
				}
			}
			buffer.add(message3);
			System.out.println("Farmer 3 put " + message3 + " up for sale");

			// Lets all the other threads that they can continue.
			notifyAll();
		}


		// synchronized method that reads the sent fruit from the FuitProducer class.
		public synchronized void put4(String message4)
		{
			// Makes the farmer wait in a Queue if the market is full.
			while(isFull())
			{
				System.out.println("Farmer 4 waiting to put one Watermelon up for sale...");
				try
				{
					// sets the current thread to wait
					wait();
				}
				catch(InterruptedException ex)
				{
					System.out.println(ex);
				}
			}
			buffer.add(message4);
			System.out.println("Farmer 4 put " + message4 + " up for sale");

			// Lets all the other threads that they can continue.
			notifyAll();
		}



		// Allow the customer to buy a fruit from the market place.
		public synchronized String get()
		{
			String message = null;

			// Makes the customer wait until the market place has fruits for sale.
			while(isEmpty())
			{
				System.out.println("Customer 1 is waiting to buy one item");
				try
				{
					//set the current thread to wait
					wait();
				}
				catch(InterruptedException ex)
				{
					System.out.println(ex);
				}
			}

			// customer buys the first fruit thats avalible for sale.
			message = buffer.remove(0);

			// allows the waiting threads to continue.
			notifyAll();
			return message;
		}


		// Allow the customer to buy a fruit from the market place.
		public synchronized String get2()
		{
			String message2 = null;

			// Makes the customer wait until the market place has fruits for sale.
			while(isEmpty())
			{
				System.out.println("Customer 2 is waiting to buy one item");
				try
				{
					//set the current thread to wait
					wait();
				}
				catch(InterruptedException ex)
				{
					System.out.println(ex);
				}
			}

			// allows the waiting threads to continue.
			message2 = buffer.remove(0);

			//wake up all the waiting thread to proceed
			notifyAll();
			return message2;
		}

		// Allow the customer to buy a fruit from the market place.
		public synchronized String get3()
		{
			String message3 = null;

			// Makes the customer wait until the market place has fruits for sale.
			while(isEmpty())
			{
				System.out.println("Customer 3 is waiting to buy one item");
				try
				{
					//set the current thread to wait
					wait();
				}
				catch(InterruptedException ex)
				{
					System.out.println(ex);
				}
			}

			// customer buys the first fruit thats avalible for sale.
			message3 = buffer.remove(0);

			// allows the waiting threads to continue.
			notifyAll();
			return message3;
		}
		// Allow the customer to buy a fruit from the market place.
		public synchronized String get4()
		{
			String message4 = null;

			// Makes the customer wait until the market place has fruits for sale.
			while(isEmpty())
			{
				System.out.println("Customer 4 is waiting to buy one item");
				try
				{
					//set the current thread to wait
					wait();
				}
				catch(InterruptedException ex)
				{
					System.out.println(ex);
				}
			}

			// customer buys the first fruit thats avalible for sale.
			message4 = buffer.remove(0);

			// allows the waiting threads to continue.
			notifyAll();
			return message4;
		}

}